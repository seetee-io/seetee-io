# 🟠 Seetee

## Running the dev environment

- Clone this repository, `git clone git@github.com:...`
- `cd` into the directory it was cloned into
- Run `yarn start` which will start a dev server on `localhost:8000`

✨
